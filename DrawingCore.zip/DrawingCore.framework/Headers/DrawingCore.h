//
//  DrawingCore.h
//  DrawingCore
//
//  Created by Yves Yang on 26/09/2016.
//  Copyright © 2016 Soyatec. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DrawingCore.
FOUNDATION_EXPORT double DrawingCoreVersionNumber;

//! Project version string for DrawingCore.
FOUNDATION_EXPORT const unsigned char DrawingCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DrawingCore/PublicHeader.h>


